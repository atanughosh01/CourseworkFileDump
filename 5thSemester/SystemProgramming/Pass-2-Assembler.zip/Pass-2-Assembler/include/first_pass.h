#ifndef FPC_H
#define FPC_H
#include <main.h>
#include <trie.h>
#include <parser.h>

void validate_and_find(Line *);

#endif
